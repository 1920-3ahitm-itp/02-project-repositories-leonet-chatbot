set -e
./build-html-docker.sh
./build-reveal-docker.sh
./build-pdf-docker.sh
