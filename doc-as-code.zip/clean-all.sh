set -e
rm -rf ./build-docs-pdf
rm -rf ./build-docs-revealjs
rm -rf ./asciidocs/revealjs